export default {
  edit_user: "Edit user",
  delete_user: "Delete user",
  send_invitation: "Send invitation",
  light_mode: "Light mode",
  dark_mode: "Dark mode",
  pin_article: "Pin article",
  unpin_article: "Unpin article",
  hide_article: "Hide article",
  show_article: "Show article",
  manage_curation: "Manage curation",
  delete_curation: "Delete curation"
};