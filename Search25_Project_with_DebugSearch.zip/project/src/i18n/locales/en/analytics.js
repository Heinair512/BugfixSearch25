export default {
  dashboard: "Analytics Dashboard",
  conversion_rate: "Conversion Rate",
  total_searches: "Total Searches",
  no_results_rate: "Zero Result Rate",
  search_term: "Search Term",
  searches: "Searches",
  clicks: "Clicks",
  position: "Position",
  business_unit: "Business Unit",
  view_all: "View All",
  no_result_searches: "Zero Result Searches",
  low_click_searches: "Low Click Searches",
  top_clicked_searches: "Top Clicked Searches"
};