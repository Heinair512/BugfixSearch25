export default {
  edit_user: "Nutzer bearbeiten",
  delete_user: "Nutzer löschen",
  send_invitation: "Einladung senden",
  light_mode: "Heller Modus",
  dark_mode: "Dunkler Modus",
  pin_article: "Artikel pinnen",
  unpin_article: "Artikel entpinnen",
  hide_article: "Artikel ausblenden",
  show_article: "Artikel einblenden",
  manage_curation: "Curation verwalten",
  delete_curation: "Curation löschen"
};