export default {
  dashboard: "Analytics Dashboard",
  conversion_rate: "Conversion Rate",
  total_searches: "Gesamtsuchen",
  no_results_rate: "Nulltreffer Rate",
  search_term: "Suchbegriff",
  searches: "Suchen",
  clicks: "Klicks",
  position: "Position",
  business_unit: "Business Unit",
  view_all: "Alle anzeigen",
  no_result_searches: "Nulltreffer",
  low_click_searches: "Suchen mit wenig Klicks",
  top_clicked_searches: "Top geklickte Suchen"
};