// Import commands.js using ES2015 syntax:
import './commands';