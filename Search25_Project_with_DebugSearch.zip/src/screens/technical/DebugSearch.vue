
<template>
  <div class="debug-search">
    <h2>Debug-Suche</h2>
    <div v-if="products.length">
      <div class="product-card" v-for="product in products" :key="product.id">
        <img :src="product.imageUrl" alt="Produktbild" />
        <div class="info">
          <p><strong>{{ product.description }}</strong></p>
          <p>Lieferant: {{ product.supplier }}</p>
          <p>Artikelnummer: {{ product.productNumber }}</p>
          <p>Preis: {{ product.grosPrice.toFixed(2) }} €</p>
        </div>
      </div>
    </div>
    <p v-else>Daten werden geladen…</p>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { fetchDebugSearchData } from '@/data/debugSearch.mock';

const products = ref([]);

onMounted(async () => {
  const response = await fetchDebugSearchData();
  products.value = response.products;
});
</script>

<style scoped>
.debug-search {
  padding: 1rem;
}
.product-card {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
  border: 1px solid #ccc;
  padding: 1rem;
  border-radius: 8px;
}
.product-card img {
  width: 100px;
  height: auto;
  margin-right: 1rem;
}
</style>
