
export const fetchDebugSearchData = async () => {
  return {
    hits: 10,
    took: 13,
    products: [
      { id: "GEN0", description: "Generischer Artikel 100000", supplier: "COST08", grosPrice: 91.28, productNumber: "GEN0", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN1", description: "Generischer Artikel 100001", supplier: "KANE03", grosPrice: 91.28, productNumber: "GEN1", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN2", description: "Generischer Artikel 100002", supplier: "INRH02", grosPrice: 91.28, productNumber: "GEN2", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN3", description: "Generischer Artikel 100003", supplier: "ITLA02", grosPrice: 91.28, productNumber: "GEN3", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN4", description: "Generischer Artikel 100004", supplier: "TEBR01", grosPrice: 91.28, productNumber: "GEN4", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN5", description: "Generischer Artikel 100005", supplier: "COST08", grosPrice: 91.28, productNumber: "GEN5", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN6", description: "Generischer Artikel 100006", supplier: "KANE03", grosPrice: 91.28, productNumber: "GEN6", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN7", description: "Generischer Artikel 100007", supplier: "INRH02", grosPrice: 91.28, productNumber: "GEN7", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN8", description: "Generischer Artikel 100008", supplier: "ITLA02", grosPrice: 91.28, productNumber: "GEN8", imageUrl: "https://via.placeholder.com/150" },
      { id: "GEN9", description: "Generischer Artikel 100009", supplier: "TEBR01", grosPrice: 91.28, productNumber: "GEN9", imageUrl: "https://via.placeholder.com/150" }
    ]
  };
};
